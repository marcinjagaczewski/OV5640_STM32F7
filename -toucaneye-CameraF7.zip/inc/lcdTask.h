#ifndef LCDTASK_H
#define LCDTASK_H

void vTaskLCD( void * pvParameters );

#endif