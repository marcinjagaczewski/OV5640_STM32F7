#ifndef _CAMERA_TASK
#define _CAMERA_TASK

void vTaskCAMERA( void * pvParameters );

#endif
