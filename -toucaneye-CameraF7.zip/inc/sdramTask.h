#ifndef SDRAMTASK_H
#define SDRAMTASK_H

void vTaskSDRAM( void * pvParameters );

#endif