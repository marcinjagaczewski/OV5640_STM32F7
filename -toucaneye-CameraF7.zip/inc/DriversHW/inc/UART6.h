#ifndef __UART6_HANDLER
#define __UART6_HANDLER

void uart6Init(void);
#endif