#ifndef __GPIO_HANDLER
#define __GPIO_HANDLER

void gpioLedInit(void);
void toggleLed(void);

#endif