#ifndef __DCMI_HANDLER
#define __DCMI_HANDLER

#include "stm32f7xx.h"

void dcmiInit(void);
void cameraPwrUp(void);
void cameraPwrDown(void);
// DCMI_HandleTypeDef dcmiGetHandler(void);



#endif
